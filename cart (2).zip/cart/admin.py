from django.contrib import admin
from cart.models import *
# Register your models here.
admin.site.register(Divicecart)
admin.site.register(Order)
admin.site.register(Medcart)
admin.site.register(MedicineOrder)